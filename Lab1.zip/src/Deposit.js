import React, { useState } from 'react';

function Deposit({ updateBalance }) {
  const [accountNumber, setAccountNumber] = useState('');
  const [amount, setAmount] = useState('');

  const handleDeposit = () => {
    updateBalance(accountNumber, amount, 'deposit');
    setAccountNumber('');
    setAmount('');
  };

  return (
    <div>
      <h3>Deposit Form</h3>
      <form>
        <div className="form-group">
          <label>Account Number:</label>
          <input
            type="text"
            className="form-control"
            value={accountNumber}
            onChange={(e) => setAccountNumber(e.target.value)}
          />
        </div>
        <div className="form-group">
          <label>Amount:</label>
          <input
            type="number"
            className="form-control"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
          />
        </div>
        <button type="button" className="btn btn-success" onClick={handleDeposit}>
          Deposit
        </button>
      </form>
    </div>
  );
}

export default Deposit;
