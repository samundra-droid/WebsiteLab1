import React from 'react';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import locationIcon from './location.jpg';
import contactIcon from './contact.jpg';
import bankYourWayIcon from './bankyourway.jpg';
import bankLogo from './bank.jpg';
import largeImage from './largeimage.jpg';
import branchLocationImage from './branch.jpg';
import boxImage1 from './image1.jpg';
import boxImage2 from './image2.jpg';
import boxImage3 from './image3.jpg';
import boxImage4 from './image4.jpg';
import boxImage5 from './image5.jpg';
import boxImage6 from './image6.jpg';
import bottomImage from './footer.jpg'; // Image for the footer
import questionIcon from './question.jpg'; // Replace with actual icon
import phoneIcon from './call.jpg'; // Replace with actual icon
import adviceIcon from './advice.jpg'; // Replace with actual icon

function App() {
  const [activeTab, setActiveTab] = React.useState('Featured');

  const handleTabClick = (tabName) => {
    setActiveTab(tabName);
  };

  return (
    <div className="App">
      {/* Main Navigation */}
      <nav className="main-nav">
        <div className="container d-flex justify-content-start">
          <a href="#" className="main-link">Personal</a>
          <a href="#" className="main-link">Small Business</a>
          <a href="#" className="main-link">Commercial</a>
          <a href="#" className="main-link">About Us</a>
          <a href="#" className="main-link">Investors</a>
        </div>
      </nav>

      {/* Top Header with ScotiaBank, Search Box, and Action Links */}
      <nav className="navbar navbar-light bg-light">
        <div className="container d-flex justify-content-between align-items-center header-row">
          <div className="scotiabank-container d-flex align-items-center">
            <a href="#" className="scotiabank-logo">
              <img src={bankLogo} alt="bank" className="icon" /> Scotiabank
            </a>
            <div className="search-box">
              <input type="text" placeholder="Search" />
            </div>
          </div>

          {/* Action Links */}
          <div className="action-links d-flex">
            <div className="action-item">
              <img src={locationIcon} alt="Location" className="icon" />
              <a href="#" className="action-link">Location</a>
            </div>
            <div className="action-item">
              <img src={contactIcon} alt="Contact Us" className="icon" />
              <a href="#" className="action-link">Contact Us</a>
            </div>
            <div className="action-item">
              <img src={bankYourWayIcon} alt="Bank Your Way" className="icon" />
              <a href="#" className="action-link">Bank Your Way</a>
            </div>

            {/* Sign In Button */}
            <div className="sign-in-container">
              <button className="sign-in-button">Sign In</button>
              <p className="activate-now-text">
                New to Scotia Online? <span className="activate-now">Activate now</span>
              </p>
            </div>
          </div>
        </div>
      </nav>

      {/* Additional icons under main navigation */}
      <nav className="sub-nav">
        <div className="container d-flex justify-content-center">
          <a href="#" className="main-link">Advice+</a>
          <a href="#" className="main-link">Scene+</a>
          <a href="#" className="main-link">Bank Accounts</a>
          <a href="#" className="main-link">Credit Cards</a>
          <a href="#" className="main-link">Loans & Lines of Credit</a>
          <a href="#" className="main-link">Insurance</a>
          <a href="#" className="main-link">Fees</a>
        </div>
      </nav>

      {/* Large Image with Button */}
      <div className="large-image-container">
        <img src={largeImage} alt="Large Banner" className="large-image" />
        <button className="view-packages-button">View our packages</button>
      </div>

      {/* Tab Buttons */}
      <div className="tabs-container">
        {['Featured', 'Accounts', 'Credit Cards', 'Borrowing', 'Investments', 'Learning'].map((tab) => (
          <button
            key={tab}
            className={`tab-button ${activeTab === tab ? 'active' : ''}`}
            onClick={() => handleTabClick(tab)}
          >
            {tab}
          </button>
        ))}
      </div>

      {/* Featured Text Section */}
      {activeTab === 'Featured' && (
        <div className="featured-section">
          <h2 className="featured-title">Featured</h2>
          <p className="featured-subtext">Helping plan for your financial future</p>

          {/* Three Vertical Boxes in Two Rows */}
          <div className="boxes-container">
            <div className="box">
              <img src={boxImage1} alt="Box 1" />
            </div>
            <div className="box">
              <img src={boxImage2} alt="Box 2" />
            </div>
            <div className="box">
              <img src={boxImage3} alt="Box 3" />
            </div>
          </div>
          <div className="boxes-container">
            <div className="box">
              <img src={boxImage4} alt="Box 4" />
            </div>
            <div className="box">
              <img src={boxImage5} alt="Box 5" />
            </div>
            <div className="box">
              <img src={boxImage6} alt="Box 6" />
            </div>
          </div>
        </div>
      )}

      {/* Branch Location Section */}
      <div className="branch-location-container">
        <img src={branchLocationImage} alt="Branch Location" className="branch-location-image" />
        <button className="find-branch-button">Find your nearest branch</button>
      </div>

      {/* Footer with Disclaimer and Buttons */}
      <div className="footer-container">
        <img src={bottomImage} alt="Bottom Image" className="footer-image" />
        <p className="footer-text">Scotiabank is a trade name used by the Bank of Nova Scotia, a CIDC member.</p>

        <div className="buttons-container">
          {/* Have a question? Button */}
          <div className="button">
            <img src={questionIcon} alt="Question Icon" className="button-icon" />
            <div className="button-text">Have a question?</div>
            <div className="button-subtext">we have an answer</div>
            <a href="#" className="button-link">Help Centre</a>
          </div>

          {/* Call Scotiabank Button */}
          <div className="button">
            <img src={phoneIcon} alt="Phone Icon" className="button-icon" />
            <div className="button-text">Call Scotiabank</div>
            <div className="button-subtext">1.800.4SCOTIA</div>
            <a href="#" className="button-link">More phone numbers</a>
          </div>

          {/* Get Advice Button */}
          <div className="button">
            <img src={adviceIcon} alt="Advice Icon" className="button-icon" />
            <div className="button-text">Get advice</div>
            <div className="button-subtext">Meet with an advisor</div>
            <a href="#" className="button-link">Book an appointment</a>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;
